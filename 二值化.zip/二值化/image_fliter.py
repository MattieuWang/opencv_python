import cv2 as cv
import numpy as np

def do(value):
    print(value)

def binary_demo():
    src = cv.imread("people1.jpg",cv.IMREAD_GRAYSCALE)
    #cv.imshow("Input",src)
    cv.namedWindow("input",cv.WINDOW_AUTOSIZE)
    cv.createTrackbar("Threshold","input",0,255,do)
    t = 127
    while(True):
        t = cv.getTrackbarPos("Threshold","input")
        ret,dst = cv.threshold(src,t,255,cv.THRESH_BINARY)  #ret获取阈值 
        #threshold函数有两个返回值
        cv.imshow("binary",dst)
        c = cv.waitKey(10)
        if c==27:    #esc
            break
        

if __name__ == "__main__":
    binary_demo()
    #cv.waitKey(0)
    cv.destroyAllWindows()